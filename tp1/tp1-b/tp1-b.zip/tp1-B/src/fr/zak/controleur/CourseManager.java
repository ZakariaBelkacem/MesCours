package fr.zak.controleur;

import java.util.List;
import java.util.Vector;

import fr.zak.model.technique.Coureur;
import fr.zak.vue.Course;

public class CourseManager {
	/**
	 * la vue
	 */
	private Course viewCourse = null;

	/**
	 * represente l'instance de la classe
	 */
	private static CourseManager instance = new CourseManager();
	/**
	 * List de coureur
	 */
	private List<Coureur> ListCoureur = null;

	/**
	 * contrcuteur
	 * 
	 */
	private CourseManager() {
		ListCoureur = new Vector<Coureur>();
	}

	/**
	 * @return retourne l'instance de la classe
	 */
	public static CourseManager getInstance() {

		return instance;
	}

	/**
	 * initiliasation des coureur
	 * lancement de la course
	 */
	public void init(Course viewCourse) {
		this.viewCourse = viewCourse;
		ListCoureur.add(new Coureur("A"));
		ListCoureur.add(new Coureur("B"));
		ListCoureur.add(new Coureur("C"));
		for (Coureur coureur : ListCoureur) {
			coureur.go();
		}
	}
	/**
	 * recupere une instance de la Course
	 * @return 
	 * 		retourne vue
	 */
	public Course getView() {
		return viewCourse;
	}
}
