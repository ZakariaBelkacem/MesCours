package fr.zak.vue;

import fr.zak.controleur.CourseManager;

public class Course {

	public Course() {
		CourseManager.getInstance().init(this);
	}
	public void afficherCourse(String dosard) {
		System.out.print(dosard);
	}
	public static void main(String[] args) {
		Course course =new Course();
		
		
	}

}
