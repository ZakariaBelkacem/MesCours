package fr.zak.model.metier;

public   class  Personne  {
	/**
	 * numero de dosart 
	 */
	private String dosard;
	/***
	 * posoition du coureur
	 */
	private int position;
	/**
	 * position de la ligne arrivé
	 */
	private final static int ARRIVEE=500;
	/**
	 * construteur
	 * @param d
	 * 			la lettre du dosard
	 */
	public Personne(String d) {
		position=0;
		setDosard(d);
	}
	/***
	 * 
	 * @return
	 * 			recupere le dosard
	 */			
	public String getDosard() {
		return dosard;
	}
	/**
	 * met à jour le dosard
	 * @param d
	 * 	
	 */
	public void setDosard(String d) {
		this.dosard = d;
	}
	/**
	 *fait avancer le coureur
	 */
	public void avancer() {
		setPosition();
	}
	/**
	 * 
	 * @return
	 * 			retourne la position
	 */
	public int getPosition() {
		return position;
	}
	/**
	 * incremente la position du coureur
	 */
	public void setPosition() {
		this.position = position+1;
	}
	/**
	 * 
	 * @return
	 * 			retourne true si la position du coureur est superieur à celle de l'arrivé
	 */
	public boolean estArriver() {
		return position >= ARRIVEE;
	}
	
}
