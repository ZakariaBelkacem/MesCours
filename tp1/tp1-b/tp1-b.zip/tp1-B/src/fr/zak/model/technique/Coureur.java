package fr.zak.model.technique;





import fr.zak.controleur.CourseManager;
import fr.zak.model.metier.Personne;

public class Coureur implements Runnable {
	
	
	/**
	 * ratio de sleep
	 */
	private int ratio;
	/**
	 * une reference vers personne
	 */
	private Personne personne = null;

	/**
	 * un thread qui permet de simuler l'avancer des coureurs
	 */
	private Thread jambes = null;

	/**
	 * prend en paramtre une personne
	 * 
	 * @param personne
	 */
	public Coureur(String d) {
		ratio = 10;
		personne=new Personne(d);
		jambes = new Thread(this);
	}
	

	/**
	 * permet de faire avancer la personne en incremente la variable position
	 * recupere une instance de la vue grace au controleur et met à jour la vue
	 */
	@Override
	public void run() {
		
			while (!personne.estArriver()) {
				personne.avancer();
				CourseManager.getInstance().getView().afficherCourse(getDossard());
				try {
					Thread.sleep((long) (Math.random() * ratio));
				} catch (InterruptedException e) {
					System.out.println("interuption");
				}
			}
			
	}

	/**
	 * demarre le thread
	 */
	public void start() {
		jambes.start();
		
	}
	/**
	 * recuperer les dossard
	 */
	public String getDossard() {
		return personne.getDosard();
		
	}
	/**
	 * lance le thread
	 */
	public void go() {
		start();
	}
	
	
	
	
	
}
