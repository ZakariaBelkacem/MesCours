package fr.zak.model.metier;

public abstract class  Personne  {
	/**
	 * numero de dosart 
	 */
	private char dosard;
	/***
	 * posoition du coureur
	 */
	private int position;
	/**
	 * position de la ligne arrivé
	 */
	private final static int ARRIVEE=500;
	/**
	 * construteur
	 * @param d
	 * 			la lettre du dosard
	 */
	public Personne(char d) {
		position=0;
		setDosard(d);
	}
	/***
	 * 
	 * @return
	 * 			recupere le dosard
	 */			
	public char getDosard() {
		return dosard;
	}
	/**
	 * met à jour le dosard
	 * @param dosard
	 * 	
	 */
	public void setDosard(char dosard) {
		this.dosard = dosard;
	}
	/**
	 *fait avancer le coureur
	 */
	public void avancer() {
		setPosition();
	}
	/**
	 * 
	 * @return
	 * 			retourne la position
	 */
	public int getPosition() {
		return position;
	}
	/**
	 * incremente la position du coureur
	 */
	public void setPosition() {
		this.position = position+1;
	}
	/**
	 * 
	 * @return
	 * 			retourne true si la position du coureur est superieur à celle de l'arrivé
	 */
	public boolean estArriver() {
		return position >= ARRIVEE;
	}
	
}
