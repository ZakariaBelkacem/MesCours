package fr.zak.model.metier;
/**
 * CLASS COUREUR QUI HERITE DE PERSONNE 
 * ELLE PEUT AVANCER
 * EST A UNE LIGNE D'ARIVÉ
 * @author zakaria
 *
 */
public class Coureur extends Personne {
	
	public Coureur(char d) {
		super(d);
	}

}
