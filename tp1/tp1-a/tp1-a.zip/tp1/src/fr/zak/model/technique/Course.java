package fr.zak.model.technique;

import fr.zak.model.metier.Coureur;
import fr.zak.model.metier.Personne;

public class Course implements Runnable {
	/**
	 * UN THREAD 
	 */
	private Thread jambes=null;
	/**
	 * represente une personne
	 */
	private Personne personne = null;
	
	private int ratio;
	/**
	 * constructeur course
	 * la course prend en pamarete un coureur
	 * 
	 * @param personne
	 */
	public Course(Personne personne) {
		ratio=10;
		this.personne=personne;
		jambes=new Thread(this);
	}
	/**
	 * methode run 
	 * fait avancer le coureur et affiche son dosard tant qu'il est pas arrivé
	 */
	@Override
	public void run() {
		while (!personne.estArriver()) {
			personne.avancer();
			System.out.print(personne.getDosard());
			try {
				Thread.sleep((long) (Math.random() * ratio));
			} catch (InterruptedException e) {
				System.out.print(personne.getDosard() + " a perdu!!!!!");
			}

		}
	}
	/**
	 * permet de démarer le thread
	 */
	public void start() {
		jambes.start();
	}
	/**
	 * lance le thread
	 */
	public void go() {
		start();
	}

	public static void main(String[] args) {
		Course course1=null;
		Course course2=null;
		Course course3=null;
		course1=new Course(new Coureur('A'));
		course1.go();
		course2=new Course(new Coureur('B'));
		course2.go();
		course3=new Course(new Coureur('C'));
		course3.go();

	}

}
